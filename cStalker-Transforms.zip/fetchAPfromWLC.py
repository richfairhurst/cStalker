#!/usr/bin/python

from MaltegoTransform import *
from sqlalchemy import *


TRX = MaltegoTransform()
wlc_name = sys.argv[1]

def main():
 db = create_engine('sqlite://///Users/rich/Sites/scripts/cstalker.db')
 # db.echo = True
 metadata = MetaData(db)
 wifi = Table('cStalker', metadata, autoload=True)
 s = select([wifi.c.Access_Point]).where (wifi.c.WLC_Name == wlc_name).distinct()
 r = db.execute(s)
 results = r.fetchall()
 results = [t[0] for t in results]
 TRX = MaltegoTransform()
 for ap in results:
 	NewEnt=TRX.addEntity("cStalker.AccessPoint", ap)
 TRX.returnOutput()

main()

