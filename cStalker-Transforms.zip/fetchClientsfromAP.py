#!/usr/bin/python

from MaltegoTransform import *
from sqlalchemy import *


TRX = MaltegoTransform()
ap = sys.argv[1]

def main():
 db = create_engine('sqlite://///Users/rich/Sites/scripts/cstalker.db')
 # db.echo = True
 metadata = MetaData(db)
 wifi = Table('cStalker', metadata, autoload=True)
 s = select([wifi.c.MAC_Address]).where (wifi.c.Access_Point == ap).distinct()
 r = db.execute(s)
 results = r.fetchall()
 results = [t[0] for t in results]
 TRX = MaltegoTransform()
 for c in results:
 	NewEnt=TRX.addEntity("cStalker.Client", c)
 TRX.returnOutput()

main()

