#!/usr/bin/python

from MaltegoTransform import *
from sqlalchemy import *
import os

TRX = MaltegoTransform()
client = sys.argv[1]

def main():
 db = create_engine('sqlite://///Users/rich/Sites/scripts/cstalker.db')
 # db.echo = True
 metadata = MetaData(db)
 wifi = Table('cstalker', metadata, autoload=True)
 s = select([wifi.c.WLC_Name]).where (wifi.c.Username == client).distinct()
 r = db.execute(s)
 results = r.fetchall()
 results = [t[0] for t in results]
 TRX = MaltegoTransform()
 for u in results:
 	NewEnt=TRX.addEntity("cStalker.WLC", u)
 TRX.returnOutput()

main()

