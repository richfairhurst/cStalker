#!/usr/bin/python

from MaltegoTransform import *
from sqlalchemy import *


TRX = MaltegoTransform()
client = sys.argv[1]

def main():
 db = create_engine('sqlite://///Users/rich/Sites/scripts/cstalker.db')

 metadata = MetaData(db)
 wifi = Table('cStalker', metadata, autoload=True)
 s = select([wifi.c.Username]).where (wifi.c.WLC_Name == client).distinct()
 r = db.execute(s)
 results = r.fetchall()
 results = [t[0] for t in results]
 TRX = MaltegoTransform()
 for u in results:
 	NewEnt=TRX.addEntity("cStalker.Username", u)
 TRX.returnOutput()

main()

